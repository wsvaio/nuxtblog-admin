<script setup lang="ts">
import { useRequest } from "vue-request";

// import IError from "~icons/fluent/cloud-error-24-regular?raw";

const { name } = defineProps<{
	name?: string;
}>();

const IError
	= "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M12 4.5a4.5 4.5 0 0 0-4.495 4.285a.75.75 0 0 1-.75.715H6.5a3 3 0 1 0 0 6h3.576a6.554 6.554 0 0 0-.057 1.5H6.5a4.5 4.5 0 0 1-.42-8.98a6.001 6.001 0 0 1 11.84 0a4.5 4.5 0 0 1 4.053 4.973a6.534 6.534 0 0 0-1.8-1.857A3 3 0 0 0 17.5 9.5h-.256a.75.75 0 0 1-.749-.715A4.5 4.5 0 0 0 12 4.5Zm10 12a5.5 5.5 0 1 1-11 0a5.5 5.5 0 0 1 11 0ZM16.5 13a.5.5 0 0 0-.5.5v4a.5.5 0 0 0 1 0v-4a.5.5 0 0 0-.5-.5Zm0 7.125a.625.625 0 1 0 0-1.25a.625.625 0 0 0 0 1.25Z\"/></svg>";

const { data } = useRequest(async () => await iconifyRaw({ p: { name } }), {
	refreshDeps: [$$(name)],
});
</script>

<template>
	<n-icon v-html="data?.includes('svg') ? data : IError" />
	<!-- <el-icon>
		<el-image :src="`https://api.iconify.design/${name}.svg`" />
	</el-icon> -->
</template>

<style lang="less"></style>
