<script setup lang="ts"></script>

<template>
	<div class="global-loading">
		<div class="loader" />
	</div>
</template>
