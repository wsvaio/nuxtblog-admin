<script setup lang='ts'>

</script>

<template>
	<h1>world hello</h1>
</template>

<style lang='less' scoped>

</style>
