import { Progress } from "@wsvaio/utils";

Progress.color = "var(--primary-color)";
Progress.errColor = "var(--error-color)";
Progress.zIndex = 9999;
