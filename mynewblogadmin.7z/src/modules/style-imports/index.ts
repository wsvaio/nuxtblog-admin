import "normalize.css";

import "@/styles/naive-ui.less";
import "@/styles/global-loading.css";
import "@/styles/main.less";

import "uno.css";
