import { defineStore } from "pinia";

export default defineStore("main", {
	state: () => ({}),
	actions: {},
	getters: {},
});
