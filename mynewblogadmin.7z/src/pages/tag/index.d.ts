export type Payload = {
	showAddedit?: boolean;
	addeditTitle?: string;
	tagId?: string;
	params: Record<any, any>;
};
