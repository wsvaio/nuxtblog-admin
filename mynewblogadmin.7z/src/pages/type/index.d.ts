export type Payload = {
	showAddedit?: boolean;
	addeditTitle?: string;
	id?: string;
	params: Record<any, any>;
};
