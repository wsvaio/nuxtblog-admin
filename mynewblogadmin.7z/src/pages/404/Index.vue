<script setup lang="ts"></script>

<template>
	<n-result status="404" title="404 资源不存在" description="生活总归带点荒谬" p="48px">
		<template #footer>
			<n-button @click="$router.push('/')">找点乐子吧</n-button>
		</template>
	</n-result>
</template>

<style lang="less"></style>
