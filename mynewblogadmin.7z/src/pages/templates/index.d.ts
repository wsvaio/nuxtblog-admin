export type Payload = {
	showDetail?: boolean;
	showAdd?: boolean;
	params: Record<any, any>;
};
